import React from 'react'

function HomePage() {
    return (
        <div>
            <h1>Welcome to My Blogging Website</h1>
            <h3>Navigate from the Navbar to access the contents of my web</h3>

            <h1 className="m-10">This could be your Blog:</h1>

            <div className="container blog-temp">
                <h1>Your Blog's Title</h1>
                <h3>Your Name (Your are the author)</h3>
                <h4>Your Blogs's Content would be Here</h4>
            </div>
        </div>
    )
}

export default HomePage
